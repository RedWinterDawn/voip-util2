<html><head><title>The Tool</title></head>
<body>
  <p>This tool has actually been replaced. Instead, go to the <a href='pbx-availability.php'>PBX Availability</a> page and simply enter the message into the message box next to the pbx you wish to use. Press enter to submit the form.</p> 
