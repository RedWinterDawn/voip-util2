#!/usr/bin/python2.6
import os
import psycopg2
import jobobject
import select
import time
import sys
from multiprocessing import Process

def init():
    if os.path.isfile('/var/run/cdr-to-csv'):
        print "Already running"
        sys.exit()
    file = open('/var/run/cdr-to-csv', 'w+')
    file.write('/opt/cdrtool/cdr-to-csv currently running')
    file.close()
    os.chdir('/opt/cdrtool/')
    newlist = os.listdir('new')
    prolist = os.listdir('progress')
    donelist = os.listdir('done')

    jobs = [jobobject.Job('new', n) for n in newlist] + [jobobject.Job('progress', p) for p in prolist] + [jobobject.Job('done', d) for d in donelist]
    return jobs

def findNew(jobs):
    before = jobobject.Job.jobfiles
    after = dict ([(f, None) for f in os.listdir ('new')])
    added = [f for f in after if not f in before]
    removed = [f for f in before if not f in after]
    jobs += [jobobject.Job('new', n) for n in added]
    return jobs

print "Finding jobs..."

jobs = init()

print "Done"
print "Starting Main Loop"
try:
    while True:
        jobs = findNew(jobs)
        for j in jobs:
            if j.status == 'new' and jobobject.Job.jobfiles[j.name] == None:
                jobobject.Job.jobfiles[j.name] = Process(target=j.startJob)
                jobobject.Job.jobfiles[j.name].start() 
            if j.status == 'done':
                j.cleanUp()
            if j.status == 'deleted':
                del j
        print '.'
        time.sleep(5)
except KeyboardInterrupt:
    print "\nSo you want to quit? Ok... one sec"
    for j in jobs:
        if jobobject.Job.jobfiles[j.name] != None:
            print "Found job in progress, sending quit signal"
            jobobject.Job.jobfiles[j.name].terminate()
            print "You'll need to manually move jobs from the progress folder to the new folder if there are any that didn't finish"
    print "Removing lock"
    os.unlink('/var/run/cdr-to-csv')
    print "Exiting!"
