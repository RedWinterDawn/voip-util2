import pickle
import os
import smtplib
import shutil
import psycopg2
import datetime

class Job:
    jobfiles = {}
    def __init__(self, status, name):
        print "New job " + name
        self.status = status
        self.name = name
        self.path = status + '/' + name
        file = open(self.path)
        self.info, self.flags = pickle.load(file)
        file.close()
        beginClause = "COPY ("
        selectClause = """SELECT {0} FROM cdr """.format(','.join(self.flags))
        if self.info['method'] == "did":
            whereClause = """WHERE (src like '{0}' OR dst like '{1}')""".format(self.info['search'], self.info['search'])
        else: 
            whereClause = """WHERE (source_pbx_id = '{0}' OR destination_pbx_id = '{1}')""".format(self.info['search'], self.info['search'])

        whenClause = """AND "end" BETWEEN '{0}' AND '{1}'""".format(self.info['begin'], self.info['end'])
        destClause = """) TO '/opt/cdrtool/csv/{0}.csv' WITH CSV HEADER""".format(self.name)
        self.query = beginClause + selectClause + whereClause + whenClause + destClause
        Job.jobfiles[name] = None

    def changeStatus(self, newStatus):
        shutil.move(self.path, newStatus)
        self.status = newStatus
        self.path = newStatus + '/' + self.name

    def startJob(self):
	self.changeStatus('progress')
        conn = psycopg2.connect(host='cdr', user='postgres', database='asterisk')
        cur = conn.cursor()
        cur.execute(self.query)
        conn.close()
        self.finished()

    def finished(self):
        print "Finished " + self.name
        self.changeStatus('done')
	Job.jobfiles[self.name] = None
        self.notifyUser()

    def notifyUser(self):
        fromAddr = 'cdr2csv@billing.jive.com'
        toAddr = self.info['email']
        subject = 'Job ' + self.name + ' ready for download'
        body = 'Hello,\n\nYour call detail record request has finished processing. You can download it at http://cdrtool.devops.jive.com/csv/'+self.name+'.csv when you are ready.'
        msg = 'Subject: %s\n\n%s' % (subject, body)

        server = smtplib.SMTP('localhost')
        server.sendmail(fromAddr, toAddr, msg)
        server.quit

    def cleanUp(self):
        if datetime.date.today() - self.info['date'] > datetime.timedelta(days=7):
            try: 
                os.unlink(self.status + "/" + self.name)
                os.unlink("csv/"+ self.name +".csv")
            except: 
                pass
            finally:
                del Job.jobfiles[self.name]
                self.status = 'deleted'
