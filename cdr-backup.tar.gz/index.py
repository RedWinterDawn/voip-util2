#!/usr/bin/python2.6
import cgi
import cgitb; cgitb.enable()
import os
import psycopg2
import pickle
import datetime
import tempfile
import re

print "Content-Type: text/html"
print 
print "<!doctype html>"
print "<html><head>"
print "<title>CDR Request Form</title>"
print "<link rel='stylesheet' href='css/datepicker.css'>"
print "<link rel='stylesheet' href='css/bootstrap.css'>"
print "<script type='text/javascript'>function setFocus() { document.getElementById('searchBox').focus(); } \n\
function validate() { \n\
    var email = document.forms['flagform']['email'].value; \n\
    if (email == null || email.match(/^[\w.]+@[\w.-]+$/) == null) {\n\
        alert('Make sure you have entered a valid email');\n\
        return false;\n\
    }\n\
} \n\
</script>"
print "</head>"
print "<body onload='setFocus()'><div style='margin-left:10px'>"
print "<h2>CDR Request Form</h2>"
print "<div><form style='float:left' action=''><input type='submit' value='Start Over' /></form><form style='float:left' action='' method='GET'><input type='hidden' name='action' value='jobs' /><input type='submit' value='See Jobs' /></form></div><p><br><br>"

def Submit():
    date = datetime.date.today() 
    info = {"method":post['method'].value, "email":post['email'].value, "begin":post['begin'].value, "end":post['end'].value, "search":post['search'].value, "date":date, "readable":post['readable'].value}
    getflags = post.getlist('flags')
    autoflags = ['calldate', 'src', 'dst', 'duration']
    flags = autoflags + getflags

    filedata = tempfile.mkstemp(prefix='cdr-', dir='/opt/cdrtool/new')
    newfile = open(filedata[1], 'w+')
    pickle.dump((info,flags), newfile)
    job = filedata[1].split('/')
    print "<p>This job has been submitted with id <b>" + job[4] + "</b></p>"
    return

def Specify(search, method, domain):
    print "<h3>Using: " + domain + "</h3>"
    print "Enter a Date Range using the date pickers below."
    print "<br>The start date should be chronologically before the end date, (e.g. start in 2010, end in 2012)"
    print "<form name='flagform' action='' method='POST' onsubmit='return(validate())'> \n\
        <input type='hidden' name='action' value='submit' /> \n\
        <input type='hidden' name='search' value='"+search+"' /> \n\
        <input type='hidden' name='method' value='"+method+"' /> \n\
        <input type='hidden' name='readable' value='"+domain+"' />\n\
        Start: \n\
        <div class='input-append date'>\n\
            <input type='text' class='span2' name='begin'><span class='add-on'><i class='icon-th'></i></span>\n\
        </div><br>\n\
        End: \n\
        <div class='input-append date'>\n\
            <input type='text' class='span2' name='end'><span class='add-on'><i class='icon-th'></i></span>\n\
        </div><br>\n\
        Select the fields you wish to include (NOTE: Call date/time, Source Number, Destination Number, and Duration are included automatically): <br> \n\
        &#10003; Call Date/Time<br>\n\
        &#10003; Source Number<br>\n\
        &#10003; Destination Number<br>\n\
        &#10003; Duration<br>\n\
        <input type='checkbox' name='flags' value='answer'>Time Answered<br> \n\
        <input type='checkbox' name='flags' value='\"end\"'>Call End Time<br> \n\
        <input type='checkbox' name='flags' value='clid'>Caller ID<br> \n\
        <input type='checkbox' name='flags' value='dcontext'>Inbound/Outbound<br> \n\
        <input type='checkbox' name='flags' value='lastapp'>Last App<br> \n\
        <input type='checkbox' name='flags' value='billsec'>Billable Seconds<br> \n\
        <input type='checkbox' name='flags' value='disposition'>Disposition (answered, not)<br> \n\
        <input type='checkbox' name='flags' value='source_pbx_id'>Source PBX ID<br> \n\
        <input type='checkbox' name='flags' value='destination_pbx_id'>Destination PBX ID<br> \n\
        <input type='checkbox' name='flags' value='sipcallid'>SIP Call ID<br> \n\
        <input type='checkbox' name='flags' value='billable'>Billable<br> \n\
        <input type='checkbox' name='flags' value='recorded'>Recorded<br> \n\
        <input type='checkbox' name='flags' value='ext_info'>Extension Info<br> \n\
        <input type='checkbox' name='flags' value='did_info'>DID Info<br> \n\
        <br>Enter the Email Address where this report should be delivered:<br> \n\
        <input type='text' name='email' placeholder='bob@example.com' /><br>\n\
        <input type='submit' value='Send Request' /> \n\
        </form>"
    print "<script src='js/jquery-1.9.1.min.js'></script>"
    print "<script src='js/bootstrap-datepicker.js'></script>"
    print "<script type='text/javascript'> \n\
        $(document).ready(function () { \n\
        $('.date').datepicker({ \n\
            weekStart: 0, \n\
            startDate: \"2010-05-01\",\n\
            endDate: \"2020-12-31\"\n\
        });\n\
        });\n\
        </script>"

def newSearch():
    search = post['search'].value
    method = post['method'].value
    if method == 'did':
        if re.match('^\d{7,20}$', search):
            Specify(search, method, search)
        else:
            print "<p class='red'>For phone numbers, please use at least 7 digits, and don't include other symbols</p>"
            Start()
        return

    if not re.match('^[\w-]*$', search):
        print "<p class='red'>Please use lowercase letters, numbers, and hyphens only.</p>"
        Start()
        return
    query = "SELECT id, domain, name FROM resource_group WHERE domain LIKE '%"+search+"%'"
    conn = psycopg2.connect('host=10.101.4.1 user=postgres dbname=pbxs')
    cur = conn.cursor()
    cur.execute(query)
    clientList = cur.fetchall()  
    conn.close()
    if len(clientList) == 1:
        Specify(clientList[0][0], method, clientList[0][1])
        return

    if len(clientList) == 0:
        print "<p class='red'>I didn't find any clients to match your search</p>"
        Start()
        return

    print "<p>Choose a client below</p>"
    print "<table border='1'><tr><th>Name</th><th>Domain</th><td></td></tr>"
    for client in clientList:
        print "<tr><td>{0}</td><td>{1}</td><form action='' method='POST'><td><input type='hidden' name='search' value='{2}' /><input type='submit' value='Use this client' /><input type='hidden' name='action' value='specify' /><input type='hidden' name='domain' value='{3}' /><input type='hidden' name='method' value='{4}' /></td></form></tr>".format(client[2], client[1], client[0], client[1], method)
    print "</table>"

def Start():
    print "<p>Enter your search term below</p>"
    print "<form action='' method='POST'>\n \
        <input type='hidden' name='action' value='search' />\n \
        <input type='radio' name='method' value='domain' checked />Domain<br>\n \
        <input type='radio' name='method' value='did' />Phone Number<br>\n \
        <input id='searchBox' type='text' name='search' placeholder='Domain or DID' />\n \
        <input type='submit' value='Search' />\n \
        </form>"
    return

def getOrderedFiles(dir):
    if dir[0] is not '/' or dir[-1] is not '/':
        print "There is a problem with the path given for jobs"
        return []
    
    os.chdir(dir)
    files = filter(os.path.isfile, os.listdir(dir))
    files = [os.path.join(dir, f) for f in files]
    files.sort(key=os.path.getmtime, reverse=True)

    ordered = []
    for f in files:
        ordered.append(os.path.basename(f))
    os.chdir('..')
    return ordered

def SeeJobs():
    jobs = {}
    jobs['new'] = getOrderedFiles('/opt/cdrtool/new/')
    jobs['progress'] = getOrderedFiles('/opt/cdrtool/progress/')
    jobs['done'] = getOrderedFiles('/opt/cdrtool/done/')
    print "<meta http-equiv='refresh' content='5; URL=http://cdrtool.devops.jive.com/?action=jobs'>"
    print "<h3>New Jobs</h3>"
    print "<table border='1'><tr><td></td><th>Search</th><th>Begin</th><th>End</th><th>Email</th><th>Flags</th></tr>"
    for n in jobs['new']:
        file = open('new/'+n)
        info, flags = pickle.load(file)
        flaglist = ','.join(flags)
        print "<tr>"
        print "<form action='' method='POST'><input type='hidden' name='action' value='cancel' /n><input type='hidden' name='job' value='"+n+"' /><td><input type='submit' value='Cancel' /></td></form><td>"+info['readable']+"</td><td>"+info['begin']+"</td><td>"+info['end']+"</td><td>"+info['email']+"</td><td>"+flaglist+"</td>"
        print "</tr>"
        file.close()
    print "</table>"
    print "<h3>In Progress</h3>"
    print "<table border='1'><tr><th>Search</th><th>Begin</th><th>End</th><th>Email</th><th>Flags</th></tr>"
    for p in jobs['progress']:
        file = open('progress/'+p)
        info, flags = pickle.load(file)
        flaglist = ','.join(flags)
        print "<tr>"
        print "<td>"+info['readable']+"</td><td>"+info['begin']+"</td><td>"+info['end']+"</td><td>"+info['email']+"</td><td>"+flaglist+"</td>"
        print "</tr>"
        file.close()
    print "</table>"
    print "<h3>Finished Jobs</h3>"
    print "<small>Jobs retained for 7 days; most recent displayed first</small>"
    print "<table border='1'><tr><th>Download</th><th>Purge Date</th><th>Search</th><th>Begin</th><th>End</th><th>Email</th><th>Flags</th></tr>"
    for f in jobs['done']:
        file = open('done/'+f)
        info, flags = pickle.load(file)
        flaglist = ','.join(flags)
        purge = (info['date'] + datetime.timedelta(days=7))
        print "<tr>"
        print "<td><a href='csv/"+f+".csv'>"+f+".csv</a><td>"+purge.isoformat()+"</td></td><td>"+info['readable']+"</td><td>"+info['begin']+"</td><td>"+info['end']+"</td><td>"+info['email']+"</td><td>"+flaglist+"</td>"
        print "</tr>"
        file.close()
    print "</table>"


post = cgi.FieldStorage()
if "action" in post:
    action = post['action'].value
else:
    action = "start"

if action =='cancel':
    os.unlink('new/'+post['job'].value)
    action = 'jobs'
if action == 'search':
    newSearch()
if action == 'start':
    Start()
if action == 'submit':
    Submit()
    SeeJobs()
if action == 'specify':
    Specify(post['search'].value, post['method'].value, post['domain'].value)
if action == 'jobs':
    SeeJobs()

print "</div></body></html>"
